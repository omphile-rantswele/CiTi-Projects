public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        new Triangle(15.0D, 8.0D, 15.0D, 8.0D, 17.0D);
        new Triangle(3.0D, 2.598D, 3.0D, 3.0D, 3.0D);
    }
}
