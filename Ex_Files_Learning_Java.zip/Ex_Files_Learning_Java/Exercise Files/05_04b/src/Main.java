public class Main {

    public static void calculateTotalMealPrice() {
    }

    public static void main(String[] args) {
    }

}
